# vcenter_rce
漏洞利用，Vmware vCenter 6.5-7.0 RCE（CVE-2021-21972），上传冰蝎3，getshell

#Usage： python3 vcenter_rce -u url
![image](https://github.com/gsheller/vcenter_rce/blob/master/vcenter_rce.jpg)
